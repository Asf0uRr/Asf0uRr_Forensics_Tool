# Asf0uRr_Forensics_Tool
This Tool has introduced an effective  model for digital forensic investigation in the fields of networking, media, and memory forensics. The Tool has provided insights into the growing cybercrime landscape and the importance of digital forensics in addressing these crimes. 
 Support Security Operations Centers :SOC  play a crucial role in protecting networks and digital assets. SOCs can enhance their security analysis capabilities.

Enhanced Learning for Cyber Security Students: The investigation models outlined in this research serve as a valuable resource for individuals learning about cyber security. This not only enhances their understanding of cyber security but also prepares them for real-world scenarios in the industry . 

As for future work, it is essential to continue evolving the investigation model for all branches of digital forensics.

# How Download tool 
Firstly
You can download the tool through this command
```shell
sudo git clone https://github.com/Asf0uRr/Asf0uRr_Forensics_Tool.git
```
# Usege
To use the tool effectively, follow these steps:
1) open the folder
 ```shell
cd Asf0uRr_Forensics_Tool 
```
2) unzip Tool
   
```shell
sudo unzip Tool_compressed.zip
```
3) open folder
 ```shell
cd Asf0uRr_Forensics_Tool 
```
4)Install requirements_Asf0uRr
 ```shell
chmod +x requirements_Asf0uRr
```
 ```shell
./requirements_Asf0uRr
```
5)READY TO USE 
give tool permission
 ```shell
chmod +x Asf0uRr_Tool.sh
```
6)Ready to use :
 ```shell
./Asf0uRr_Tool.sh file
```





# 
