Writing Plugins
===============

.. toctree::

    simple-plugin
    complex-plugin
    using-as-a-library
