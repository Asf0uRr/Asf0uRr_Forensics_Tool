#!/bin/bash

# Function to print a hacker-style banner
print_banner() {
    echo -e "\e[1;36m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⠀⠀⠀⠀⠀ ⠀     ██████╗   █████╗ ███████╗███████╗██    ██ ██████╗ ██████╗                                                     \e[0m"
    echo -e "\e[1;36m⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⡟⠋⢻⣷⣄⡀⠀⠀⠀⠀     ██╔══██╗██╔════╝██╔════╝██╔═████╗██║   ██║██╔══██╗██╔══██╗                                                   \e[0m"
    echo -e "\e[1;36m⠀⠀⠀⠀⣤⣾⣿⣷⣿⣿⣿⣿⣿⣶⣾⣿⣿⠿⠿⠿⠶⠄     ███████║███████╗█████╗  ██║██╔██║██║   ██║██████╔╝██████╔╝                                                   \e[0m"
    echo -e "\e[1;36m⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠉⠀⠀⠀⠀⠀⠀     ██╔══██║╚════██║██╔══╝  ████╔╝██║██║   ██║██╔══██╗██╔══██╗                                                   \e[0m"
    echo -e "\e[1;36m⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀     ██║  ██║███████║██║     ╚██████╔╝╚██████╔╝██║  ██║██║  ██║                                                   \e[0m"
    echo -e "\e[1;36m⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀     ╚═╝  ╚═╝╚══════╝╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝                                                   \e[0m"
    echo -e "\e[1;36m ⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀                                                                                                               \e[0m"
    echo -e "\e[1;36m⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀     ███████╗ ██████╗ ██████╗ ███████╗███╗   ██╗███████╗██╗ ██████╗███████╗    ████████╗ ██████╗  ██████╗ ██╗     \e[0m"
    echo -e "\e[1;36m⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀     ██╔════╝██╔═══██╗██╔══██╗██╔════╝████╗  ██║██╔════╝██║██╔════╝██╔════╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     \e[0m"
    echo -e "\e[1;36m⠀⠀⠈⣿⣿⣿⣿⣿⣿⠟⠻⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀     █████╗  ██║   ██║██████╔╝█████╗  ██╔██╗ ██║███████╗██║██║     ███████╗       ██║   ██║   ██║██║   ██║██║     \e[0m"
    echo -e "\e[1;36m⠀⠀⣼⣿⣿⣿⣿⣿⣿⣆⣤⠿⢶⣦⡀⠀⠀⠀⠀⠀⠀⠀     ██╔══╝  ██║   ██║██╔══██╗██╔══╝  ██║╚██╗██║╚════██║██║██║     ╚════██║       ██║   ██║   ██║██║   ██║██║     \e[0m"
    echo -e "\e[1;36m⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⠑⠀⠀⠀⠀⠀⠀⠀     ██║     ╚██████╔╝██║  ██║███████╗██║ ╚████║███████║██║╚██████╗███████║       ██║   ╚██████╔╝╚██████╔╝███████╗  \e[0m"
    echo -e "\e[1;36m⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀     ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚══════╝╚═╝ ╚═════╝╚══════╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
\e[0m"
    echo -e "\e[1;36m⠸⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀
\e[0m"
    echo -e "\e[1;36m⠸⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀
\e[0m"⠀
}

# Function to display a loading bar
loading_bar() {
    local duration="$1"
    local chars="▁▂▃▄▅▆▇█▇▆▅▄▃▂▁"
    local i=0
    while [ $i -lt "$duration" ]; do
        ((i++))
        echo -ne "\e[1;33m${chars:$((i%${#chars})):1}\e[0m"
        sleep 0.05
        echo -ne "\b"  
        echo -ne "\e[0m"
    done
}

# Function to check if a file is an image
is_image() {
    local file="$1"
    # Check if the file command output contains "image"
    if file -b --mime-type "$file" | grep -q "image"; then
        return 0
    else
        return 1
    fi
}

# Function to check if a file is a pcap file
is_pcap() {
    local file="$1"
    # Check if the file command output contains "pcap"
    if file -b --mime-type "$file" | grep -q "pcap"; then
        return 0
    else
        return 1
    fi
}

# Function to check if a file is a disk image (dd or dis)
is_disk_image() {
    local file="$1"
    # Check if the file extension is .dd or .dis
    if [[ "$file" == *.dd || "$file" == *.dis ]]; then
        return 0
    else
        return 1
    fi
}

# Main function
main() {
    local file="$1"

    # Print the hacker-style banner
    print_banner

    # Display loading bar while waiting for analysis to start
    echo -e "\n\e[1;36mWaiting for analysis to start\e[0m "
    loading_bar 200

    # Check if the file is an image
    if is_image "$file"; then
        #!/bin/bash

# Function to print a framed text with a professional look
print_framed_text() {
    local text="$1"
    local frame_width="$2"
    local padding="$3"

    echo "$text" | sed "s/^/$(printf "%${padding}s")/"
}

# Function to display the menu options
display_menu() {
    echo -e "\e[1;36mMenu Options:\e[0m"
    echo -e "1. \e[1;34mInfo About File \e[0m"
    echo -e "2. \e[1;34mHide Data\e[0m"
    echo -e "3. \e[1;34mHide Files\e[0m"
    echo -e "4. \e[1;34mExtract Files\e[0m"
    echo -e "5. \e[1;34mCreate a Hex Dump of a File\e[0m"
    echo -e "6. \e[1;34mFile Type\e[0m"
    echo -e "7. \e[1;31mExit\e[0m"
}

# Function to display the return and exit options
display_return_exit_options() {
    echo -e "\e[1;33mReturn to Main Menu or Exit?\e[0m"
    echo -e "1. \e[1;32mReturn to Main Menu\e[0m"
    echo -e "2. \e[1;31mExit\e[0m"
}

# Function to hide files using binwalk
hide_files() {
    echo -e "\e[1;34mHide Files Option Selected\e[0m"
    # Run binwalk command on the file
    file_name="$1"
    echo "Running binwalk command on file: $file_name"
    binwalk_result=$(binwalk "$file_name")
    echo "$binwalk_result"
}

# Function to extract files using binwalk
extract_files() {
    echo -e "\e[1;34mExtract Files Option Selected\e[0m"
    # Run binwalk --dd='.*' command on the file
    file_name="$1"
    echo "Extracting files using binwalk command on file: $file_name"
    binwalk_result=$(binwalk --dd='.*' "$file_name")
    echo "$binwalk_result"
}

# Function to create a hex dump of a file using xxd
create_hex_dump() {
    echo -e "\e[1;34mCreate a Hex Dump of a File Option Selected\e[0m"
    # Run xxd command on the file
    file_name="$1"
    echo "Creating hex dump of file: $file_name"
    xxd_result=$(xxd "$file_name")
    echo "$xxd_result"
}

# Function to display file type using file command
display_file_type() {
    echo -e "\e[1;34mFile Type Option Selected\e[0m"
    # Run file command on the file
    file_name="$1"
    echo "Displaying file type of file: $file_name"
    file_result=$(file "$file_name")
    echo "$file_result"
}

# Clear the screen
clear

# Check if a file name is provided as a parameter
if [ $# -eq 0 ]; then
    echo -e "\e[1;31mError: Please provide a file name as a parameter.\e[0m"
    exit 1
fi

# ASCII art banner
echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   


# Display the menu options
display_menu

while true; do
    # Prompt the user to select an option
    read -p "Please select an option (1-7): " choice

    # Clear the screen before displaying the results
    clear

    # Print the framed text again
    echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
    echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
    echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
    echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
    echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
    echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   


    # Process the user's choice
    case $choice in
        1)
            echo -e "\e[1;34mExiftool Command Option Selected\e[0m"
            # Run the command `exiftool` on the entered file
            file_name="$1"
            echo "Running exiftool command on file: $file_name"
            exiftool_result=$(exiftool "$file_name")
            echo "$exiftool_result"
            ;;
        2)
            echo -e "\e[1;34mRun 'Strings' Command on File Option Selected\e[0m"
            # Run the 'strings' command on the file
            file_name="$1"
            echo "Running 'strings' command on file: $file_name"
            strings_result=$(strings "$file_name")
            echo "$strings_result"
            ;;
        3)
            hide_files "$1"
            ;;
        4)
            extract_files "$1"
            ;;
        5)
            create_hex_dump "$1"
            ;;
        6)
            display_file_type "$1"
            ;;
        7)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Please select an option from 1 to 7.\e[0m"
            ;;
    esac

    # Display the return and exit options
    display_return_exit_options

    # Prompt the user to select an option
    read -p "Please select an option (1-2): " choice

    # Process the user's choice
    case $choice in
        1)
            # Clear the screen before displaying the menu
            clear
            # Print the framed text again
            echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
            echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
            echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
            echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   

            # Display the menu options again
            display_menu
            ;;
        2)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Returning to the main menu.\e[0m"
            # Clear the screen before displaying the menu
            clear
            # Print the framed text again
            echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
            echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
            echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
            echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   

            # Display the menu options again
            display_menu
            ;;
    esac
done 

        # Place your actions for image files here
    # Check if the file is a pcap file
    elif is_pcap "$file"; then
        #!/bin/bash

# Function to print a framed text with a professional look
print_framed_text() {
    local text="$1"
    local frame_width="$2"
    local padding="$3"

    echo "$text" | sed "s/^/$(printf "%${padding}s")/"
}

# Function to display the menu options
display_menu() {
    echo -e "\e[1;36mMenu Options:\e[0m"
    echo -e "\n\e[1;33m1. \e[0m\e[1;34mDisplay Traffic\e[0m"
    echo -e "\n\e[1;33m2. \e[0m\e[1;34mOpen in Wireshark \e[0m"
    echo -e "\n\e[1;33m3. \e[0m\e[1;34mFiltering by IP\e[0m\e[1;33m.\e[0m"
    echo -e "\n\e[1;33m4. \e[0m\e[1;34mExit...\e[0m\e[1;33m.\e[0m"
}

# Function to display the return and exit options
display_return_exit_options() {
    echo -e "\e[1;33mReturn to Main Menu or Exit?\e[0m"
    echo -e "1. \e[1;32mReturn to Main Menu\e[0m"
    echo -e "2. \e[1;31mExit\e[0m"
}

# Clear the screen
clear

# Check if a file name is provided as a parameter
if [ $# -eq 0 ]; then
    echo -e "\e[1;31mError: Please provide a file name as a parameter.\e[0m"
    exit 1
fi

# ASCII art banner
echo -e "\e[1;36m███╗   ██╗███████╗████████╗██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
echo -e "\e[1;36m████╗  ██║██╔════╝╚══██╔══╝██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
echo -e "\e[1;36m██╔██╗ ██║█████╗     ██║   ██║ █╗ ██║██║   ██║██████╔╝█████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
echo -e "\e[1;36m██║╚██╗██║██╔══╝     ██║   ██║███╗██║██║   ██║██╔══██╗██╔═██╗        ██║   ██║   ██║██║   ██║██║                  \e[0m"                  
echo -e "\e[1;36m██║ ╚████║███████╗   ██║   ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗       ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By:Ali Asfour\e[0m"
echo -e "\e[1;36m╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"



# Display the menu options
display_menu

while true; do
    # Prompt the user to select an option
    read -p "Please select an option (1-4): " choice 

    # Clear the screen before displaying the results
    clear

    # Print the banner again
    echo -e "\e[1;36m███╗   ██╗███████╗████████╗██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
    echo -e "\e[1;36m████╗  ██║██╔════╝╚══██╔══╝██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
    echo -e "\e[1;36m██╔██╗ ██║█████╗     ██║   ██║ █╗ ██║██║   ██║██████╔╝█████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
    echo -e "\e[1;36m██║╚██╗██║██╔══╝     ██║   ██║███╗██║██║   ██║██╔══██╗██╔═██╗        ██║   ██║   ██║██║   ██║██║                  \e[0m"                  
    echo -e "\e[1;36m██║ ╚████║███████╗   ██║   ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗       ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By:Ali Asfour\e[0m"
    echo -e "\e[1;36m╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"



    # Process the user's choice
    case $choice in
        1)
            echo -e "\e[1;34mDisplay Traffic \e[0m"
            file_name="$1"
            tshark -r "$file_name"
            ;;
        2)
            echo -e "\e[1;34mOpen in Wireshark \e[0m"
            file_name="$1"
            wireshark "$file_name"
            ;;
        3)
            echo -e "\e[1;34mFiltering by IP \e[0m"
            file_name="$1"
            read -p "Please enter an IP: " pid_number
            tshark -r "$file_name" -Y "ip.addr == $pid_number"
            ;;
        4)
            echo -e "\e[1;34mGOODBYE ... \e[0m"
            exit 0
            ;;           
        *)
            echo -e "\e[1;31mInvalid option. Please select an option from 1 to 4.\e[0m"
            ;;
    esac

    # Display the return and exit options
    display_return_exit_options

    # Prompt the user to select an option
    read -p "Please select an option (1-2): " choice

    # Process the user's choice
    case $choice in
        1)
            # Clear the screen before displaying the menu
            clear
            # Display the banner again
            echo -e "\e[1;36m███╗   ██╗███████╗████████╗██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
            echo -e "\e[1;36m████╗  ██║██╔════╝╚══██╔══╝██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
            echo -e "\e[1;36m██╔██╗ ██║█████╗     ██║   ██║ █╗ ██║██║   ██║██████╔╝█████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
            echo -e "\e[1;36m██║╚██╗██║██╔══╝     ██║   ██║███╗██║██║   ██║██╔══██╗██╔═██╗        ██║   ██║   ██║██║   ██║██║                  \e[0m"                  
            echo -e "\e[1;36m██║ ╚████║███████╗   ██║   ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗       ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By:Ali Asfour\e[0m"
            echo -e "\e[1;36m╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"


            # Display the menu options again
            display_menu
            ;;
        2)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Returning to the main menu.\e[0m"
            # Clear the screen before displaying the menu
            clear
            # Display the banner again
            echo -e "\e[1;36m███╗   ██╗███████╗████████╗██╗    ██╗ ██████╗ ██████╗ ██╗  ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
            echo -e "\e[1;36m████╗  ██║██╔════╝╚══██╔══╝██║    ██║██╔═══██╗██╔══██╗██║ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
            echo -e "\e[1;36m██╔██╗ ██║█████╗     ██║   ██║ █╗ ██║██║   ██║██████╔╝█████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
            echo -e "\e[1;36m██║╚██╗██║██╔══╝     ██║   ██║███╗██║██║   ██║██╔══██╗██╔═██╗        ██║   ██║   ██║██║   ██║██║                  \e[0m"                  
            echo -e "\e[1;36m██║ ╚████║███████╗   ██║   ╚███╔███╔╝╚██████╔╝██║  ██║██║  ██╗       ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ BY:Ali Asfour\e[0m"
            echo -e "\e[1;36m╚═╝  ╚═══╝╚══════╝   ╚═╝    ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"


            # Display the menu options again
            display_menu
            ;;
    esac
done

        # Place your actions for pcap files here
    # Check if the file is a disk image
    elif is_disk_image "$file"; then
        #!/bin/bash

# Function to print a framed text with a professional look
print_framed_text() {
    local text="$1"
    local frame_width="$2"
    local padding="$3"

    echo "$text" | sed "s/^/$(printf "%${padding}s")/"
}

# Function to display the menu options
display_menu() {
    echo -e "\e[1;36mMenu Options:\e[0m"
    echo -e "\n\e[1;33m1. \e[0m\e[1;34mHash-Passwords\e[0m\e[1;33m.\e[0m                            \e[1;33m11. \e[0m\e[1;34mDLLs\e[0m"
    echo -e "\n\e[1;33m2. \e[0m\e[1;34mAnalysis Processes (list)\e[0m\e[1;33m.\e[0m                     \e[1;33m12. \e[0m\e[1;34mUserAssist\e[0m"
    echo -e "\n\e[1;33m3. \e[0m\e[1;34mAnalysis Processes (tree)\e[0m\e[1;33m.\e[0m                     \e[1;33m13. \e[0m\e[1;34mService Scan\e[0m"
    echo -e "\n\e[1;33m4. \e[0m\e[1;34mAnalysis Processes (scan for Malware)\e[0m\e[1;33m.\e[0m         \e[1;33m14. \e[0m\e[1;34mNetwork Scan\e[0m"
    echo -e "\n\e[1;33m5. \e[0m\e[1;34mExtract Processes\e[0m\e[1;33m.\e[0m                              \e[1;33m15. \e[0m\e[1;34mRegistry hive\e[0m"
    echo -e "\n\e[1;33m6. \e[0m\e[1;34mDisplay Command line\e[0m\e[1;33m.\e[0m                          \e[1;33m16. \e[0m\e[1;34mFile scan\e[0m"
    echo -e "\n\e[1;33m7. \e[0m\e[1;34mEnvironment of each running process\e[0m\e[1;33m.\e[0m           \e[1;33m17. \e[0m\e[1;34mSSL Keys/Certificate\e[0m"
    echo -e "\n\e[1;33m8. \e[0m\e[1;34mToken privileges\e[0m\e[1;33m.\e[0m                              \e[1;33m18. \e[0m\e[1;34mDrivers\e[0m"
    echo -e "\n\e[1;33m9. \e[0m\e[1;34mSIDs\e[0m\e[1;33m.\e[0m                                          \e[1;33m19. \e[0m\e[1;31mExit\e[0m"
    echo -e "\n\e[1;33m10.\e[0m\e[1;34mHandles\e[0m"
}









# Function to display the return and exit options
display_return_exit_options() {
    echo -e "\e[1;33mReturn to Main Menu or Exit?\e[0m"
    echo -e "1. \e[1;32mReturn to Main Menu\e[0m"
    echo -e "2. \e[1;31mExit\e[0m"
}

# Clear the screen
clear

# Check if a file name is provided as a parameter
if [ $# -eq 0 ]; then
    echo -e "\e[1;31mError: Please provide a file name as a parameter.\e[0m"
    exit 1
fi

echo -e "\e[1;36m███╗   ███╗███████╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
echo -e "\e[1;36m████╗ ████║██╔════╝████╗ ████║██╔═══██╗██╔══██╗╚██╗ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
echo -e "\e[1;36m██╔████╔██║█████╗  ██╔████╔██║██║   ██║██████╔╝ ╚████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
echo -e "\e[1;36m██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██║   ██║██╔══██╗  ╚██╔╝         ██║   ██║   ██║██║   ██║██║                  \e[0m"
echo -e "\e[1;36m██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║╚██████╔╝██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By: Ali Asfour\e[0m"
echo -e "\e[1;36m╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"


# Display the menu options
display_menu 




while true; do
    # Prompt the user to select an option
    read -p "Please select an option (1-7): " choice

    # Clear the screen before displaying the results
    clear

    # Print the framed text again
    echo -e "\e[1;36m███╗   ███╗███████╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
    echo -e "\e[1;36m████╗ ████║██╔════╝████╗ ████║██╔═══██╗██╔══██╗╚██╗ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
    echo -e "\e[1;36m██╔████╔██║█████╗  ██╔████╔██║██║   ██║██████╔╝ ╚████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
    echo -e "\e[1;36m██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██║   ██║██╔══██╗  ╚██╔╝         ██║   ██║   ██║██║   ██║██║                  \e[0m"
    echo -e "\e[1;36m██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║╚██████╔╝██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By: Ali Asfour\e[0m"
    echo -e "\e[1;36m╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"


    # Process the user's choice
    case $choice in
        1)
            echo -e "\e[1;34mHash-Passwords Option Selected\e[0m"
            # Run the command `python3 vol.py -f file windows.hashdump.Hashdump`
            file_name="$1"
            python3 vol.py -f "$file_name" windows.hashdump.Hashdump
            ;;
        2)
            echo -e "\e[1;34mAnalysis Processes -list- Option Selected\e[0m"
            # Run the command `python3 vol.py -f file windows.pstree.PsTree`
            file_name="$1"
            python3 vol.py -f "$file_name" windows.pstree.PsTree
            ;;
        3)
            echo -e "\e[1;34mAnalysis Processes -tree- Option Selected\e[0m"
            # Run the command `python3 vol.py -f file windows.pslist.PsList`
            file_name="$1"
            python3 vol.py -f "$file_name" windows.pslist.PsList
            ;;
        4)
            echo -e "\e[1;34mAnalysis Processes -scan for Malware- Option Selected\e[0m"
            # Run the command `python3 vol.py -f file windows.psscan.PsScan`
            file_name="$1"
            python3 vol.py -f "$file_name" windows.psscan.PsScan
            ;;
        5)
            echo -e "\e[1;34mExtract Processes Option Selected\e[0m"
            # Prompt the user to enter a PID number
            read -p "Please enter a PID number: " pid_number
            # Run the command `./vol.py -f file windows.dumpfiles.DumpFiles --pid <pid_number>`
            echo "Running command: ./vol.py -f $file_name windows.dumpfiles.DumpFiles --pid $pid_number"
            ./vol.py -f "$file_name" windows.dumpfiles.DumpFiles --pid "$pid_number"
            ;;
        6)
            echo -e "\e[1;34mExtract Processes Option Selected\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.cmdline.CmdLine 
            ;;
        7)
            echo -e "\e[1;34mEnvironment of each running process\e[0m"
            read -p "Please enter a PID number: " pid_number
            file_name="$1"
            python3 vol.py -f "$file_name" windows.envars.Envars --pid "$pid_number"
            ;;
        8)
            echo -e "\e[1;34mToken privileges\e[0m"
            read -p "Please enter a PID number: " pid_number
            file_name="$1"
            python3 vol.py -f "$file_name" windows.privileges.Privs --pid "$pid_number"
            ;;
        9)
            echo -e "\e[1;34mSIDs\e[0m"
            read -p "Please enter a PID number: " pid_number
            file_name="$1"
            python3 vol.py -f "$file_name" windows.getsids.GetSIDs --pid "$pid_number"
            ;;
        10)
            echo -e "\e[1;34mHandles\e[0m"
            read -p "Please enter a PID number: " pid_number
            file_name="$1"
            python3 vol.py -f "$file_name" windows.handles.Handles --pid "$pid_number"
            ;;
        11)
            echo -e "\e[1;34mDLLs\e[0m"
            read -p "Please enter a PID number: " pid_number
            file_name="$1"
            python3 vol.py -f "$file_name" windows.dlllist.DllList --pid "$pid_number"
            ;;
        12)
            echo -e "\e[1;34mUserAssist\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.registry.userassist.UserAssist
            ;;
        13)
            echo -e "\e[1;34mService Scan\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.svcscan.SvcScan
            ;;
        14)
            echo -e "\e[1;34mNetwork Scan\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.netscan.NetScan
            ;;
        15)
            echo -e "\e[1;34mRegistry hive\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.registry.hivelist.HiveList
            ;;
        16)
            echo -e "\e[1;34mFile Scan\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.filescan.FileScan
            ;;
        17)
            echo -e "\e[1;34mSSL Keys/Certficate\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.registry.certificates.Certificates
            ;;
        18)
            echo -e "\e[1;34mDrivers\e[0m"
            file_name="$1"
            python3 vol.py -f "$file_name" windows.registry.driverscan.DriverScan
            ;;
        x)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Please select an option from 1 to 7.\e[0m"
            ;;
    esac

    # Display the return and exit options
    display_return_exit_options

    # Prompt the user to select an option
    read -p "Please select an option (1-2): " choice

    # Process the user's choice
    case $choice in
        1)
            # Clear the screen before displaying the menu
            clear
            # Print the framed text again
            echo -e "\e[1;36m███╗   ███╗███████╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
            echo -e "\e[1;36m████╗ ████║██╔════╝████╗ ████║██╔═══██╗██╔══██╗╚██╗ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
            echo -e "\e[1;36m██╔████╔██║█████╗  ██╔████╔██║██║   ██║██████╔╝ ╚████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
            echo -e "\e[1;36m██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██║   ██║██╔══██╗  ╚██╔╝         ██║   ██║   ██║██║   ██║██║                  \e[0m"
            echo -e "\e[1;36m██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║╚██████╔╝██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By: Ali Asfour\e[0m"
            echo -e "\e[1;36m╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"

            # Display the menu options again
            display_menu
            ;;
        2)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Returning to the main menu.\e[0m"
            # Clear the screen before displaying the menu
            clear
            # Print the framed text again
            echo -e "\e[1;36m███╗   ███╗███████╗███╗   ███╗ ██████╗ ██████╗ ██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗                  \e[0m"
            echo -e "\e[1;36m████╗ ████║██╔════╝████╗ ████║██╔═══██╗██╔══██╗╚██╗ ██╔╝    ╚══██╔══╝██╔═══██╗██╔═══██╗██║                  \e[0m"
            echo -e "\e[1;36m██╔████╔██║█████╗  ██╔████╔██║██║   ██║██████╔╝ ╚████╔╝        ██║   ██║   ██║██║   ██║██║                  \e[0m"
            echo -e "\e[1;36m██║╚██╔╝██║██╔══╝  ██║╚██╔╝██║██║   ██║██╔══██╗  ╚██╔╝         ██║   ██║   ██║██║   ██║██║                  \e[0m"
            echo -e "\e[1;36m██║ ╚═╝ ██║███████╗██║ ╚═╝ ██║╚██████╔╝██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗ By: Ali Asfour\e[0m"
            echo -e "\e[1;36m╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝\e[0m"

            # Display the menu options again
            display_menu
            ;;
    esac
done

        # Place your actions for disk image files here
    # If the file type is unknown
    else
        #!/bin/bash

# Function to print a framed text with a professional look
print_framed_text() {
    local text="$1"
    local frame_width="$2"
    local padding="$3"

    echo "$text" | sed "s/^/$(printf "%${padding}s")/"
}

# Function to display the menu options
display_menu() {
    echo -e "\e[1;36mMenu Options:\e[0m"
    echo -e "1. \e[1;34mInfo About File \e[0m"
    echo -e "2. \e[1;34mHide Data\e[0m"
    echo -e "3. \e[1;34mHide Files\e[0m"
    echo -e "4. \e[1;34mExtract Files\e[0m"
    echo -e "5. \e[1;34mCreate a Hex Dump of a File\e[0m"
    echo -e "6. \e[1;34mFile Type\e[0m"
    echo -e "7. \e[1;31mExit\e[0m"
}

# Function to display the return and exit options
display_return_exit_options() {
    echo -e "\e[1;33mReturn to Main Menu or Exit?\e[0m"
    echo -e "1. \e[1;32mReturn to Main Menu\e[0m"
    echo -e "2. \e[1;31mExit\e[0m"
}

# Function to hide files using binwalk
hide_files() {
    echo -e "\e[1;34mHide Files Option Selected\e[0m"
    # Run binwalk command on the file
    file_name="$1"
    echo "Running binwalk command on file: $file_name"
    binwalk_result=$(binwalk "$file_name")
    echo "$binwalk_result"
}

# Function to extract files using binwalk
extract_files() {
    echo -e "\e[1;34mExtract Files Option Selected\e[0m"
    # Run binwalk --dd='.*' command on the file
    file_name="$1"
    echo "Extracting files using binwalk command on file: $file_name"
    binwalk_result=$(binwalk --dd='.*' "$file_name")
    echo "$binwalk_result"
}

# Function to create a hex dump of a file using xxd
create_hex_dump() {
    echo -e "\e[1;34mCreate a Hex Dump of a File Option Selected\e[0m"
    # Run xxd command on the file
    file_name="$1"
    echo "Creating hex dump of file: $file_name"
    xxd_result=$(xxd "$file_name")
    echo "$xxd_result"
}

# Function to display file type using file command
display_file_type() {
    echo -e "\e[1;34mFile Type Option Selected\e[0m"
    # Run file command on the file
    file_name="$1"
    echo "Displaying file type of file: $file_name"
    file_result=$(file "$file_name")
    echo "$file_result"
}

# Clear the screen
clear

# Check if a file name is provided as a parameter
if [ $# -eq 0 ]; then
    echo -e "\e[1;31mError: Please provide a file name as a parameter.\e[0m"
    exit 1
fi

# ASCII art banner
echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   


# Display the menu options
display_menu

while true; do
    # Prompt the user to select an option
    read -p "Please select an option (1-7): " choice

    # Clear the screen before displaying the results
    clear

    # Print the framed text again
    echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
    echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
    echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
    echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
    echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
    echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   


    # Process the user's choice
    case $choice in
        1)
            echo -e "\e[1;34mExiftool Command Option Selected\e[0m"
            # Run the command `exiftool` on the entered file
            file_name="$1"
            echo "Running exiftool command on file: $file_name"
            exiftool_result=$(exiftool "$file_name")
            echo "$exiftool_result"
            ;;
        2)
            echo -e "\e[1;34mRun 'Strings' Command on File Option Selected\e[0m"
            # Run the 'strings' command on the file
            file_name="$1"
            echo "Running 'strings' command on file: $file_name"
            strings_result=$(strings "$file_name")
            echo "$strings_result"
            ;;
        3)
            hide_files "$1"
            ;;
        4)
            extract_files "$1"
            ;;
        5)
            create_hex_dump "$1"
            ;;
        6)
            display_file_type "$1"
            ;;
        7)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Please select an option from 1 to 7.\e[0m"
            ;;
    esac

    # Display the return and exit options
    display_return_exit_options

    # Prompt the user to select an option
    read -p "Please select an option (1-2): " choice

    # Process the user's choice
    case $choice in
        1)
            # Clear the screen before displaying the menu
            clear
            # Print the framed text again
            echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
            echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
            echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
            echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   

            # Display the menu options again
            display_menu
            ;;
        2)
            echo -e "\e[1;31mExiting...\e[0m"
            exit 0
            ;;
        *)
            echo -e "\e[1;31mInvalid option. Returning to the main menu.\e[0m"
            # Clear the screen before displaying the menu
            clear
            # Print the framed text again
            echo -e "\e[1;36m███████╗████████╗███████╗ ██████╗  █████╗ ███╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗██╗   ██╗    ████████╗ ██████╗  ██████╗ ██╗\e[0m"                 
            echo -e "\e[1;36m██╔════╝╚══██╔══╝██╔════╝██╔════╝ ██╔══██╗████╗  ██║██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║╚██╗ ██╔╝  ╚══██╔══╝██╔═══██╗██╔═══██╗██║\e[0m"                  
            echo -e "\e[1;36m███████╗   ██║   █████╗  ██║  ███╗███████║██╔██╗ ██║██║   ██║██║  ███╗██████╔╝███████║██████╔╝███████║ ╚████╔╝        ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m╚════██║   ██║   ██╔══╝  ██║   ██║██╔══██║██║╚██╗██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║  ╚██╔╝         ██║   ██║   ██║██║   ██║██║\e[0m"                  
            echo -e "\e[1;36m███████║   ██║   ███████╗╚██████╔╝██║  ██║██║ ╚████║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║   ██║          ██║   ╚██████╔╝╚██████╔╝███████╗    ██╗██╗██╗\e[0m"
            echo -e "\e[1;36m╚══════╝   ╚═╝   ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝          ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝    ╚═╝╚═╝╚═╝ <BY:Ali Asfour>\e[0m"
                                                                                                                                                                   

            # Display the menu options again
            display_menu
            ;;
    esac
done 

        # Place your actions for unknown file types here
    fi
}

# Check if a file name is provided as a parameter
if [ $# -eq 0 ]; then
    echo -e "\e[1;31mError: Please provide a file name as a parameter.\e[0m"
    exit 1
fi

# Call the main function with the provided file path parameter
main "$1"
